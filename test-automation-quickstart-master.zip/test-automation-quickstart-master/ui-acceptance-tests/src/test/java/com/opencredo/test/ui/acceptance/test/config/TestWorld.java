package com.opencredo.test.ui.acceptance.test.config;

import java.util.HashMap;

public class TestWorld {
    public HashMap<String, String> sharedState = new HashMap<>();
}
