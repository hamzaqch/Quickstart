package com.opencredo.test.security.acceptance.test.config;

import java.util.HashMap;

public class TestWorld {
    public HashMap<String, String> sharedState = new HashMap<>();
}
