(function( $ ) {
	/**
	 * Public website Javascript
	 */

})( jQuery );
