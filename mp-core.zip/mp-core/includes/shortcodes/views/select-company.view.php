<div class="select-company">
    <h1>Type a company name</h1>
    <input type="text" placeholder="Type a company name" id="search-company-input">
    <div class="autocomplete-results-container">
        <ul id="autocomplete-results">
            <!-- <li>bar</li>
            <li>foo</li> -->
        </ul>
    </div>
</div>