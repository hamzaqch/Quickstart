(function ($) {
  /**
   * Wp Admin Javascript
   */

  window.onload = () => {

  };
})(jQuery);
